<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Coin_A" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="../sprites/items/PNG/Bonus_Items/Coin_A.png" width="128" height="128"/>
</tileset>
