<?xml version="1.0" encoding="UTF-8"?>
<data version="1.0">
    <struct type="Settings">
        <key>fileFormatVersion</key>
        <int>6</int>
        <key>texturePackerVersion</key>
        <string>7.10.0</string>
        <key>autoSDSettings</key>
        <array>
            <struct type="AutoSDSettings">
                <key>scale</key>
                <double>1</double>
                <key>extension</key>
                <string></string>
                <key>spriteFilter</key>
                <string></string>
                <key>acceptFractionalValues</key>
                <false/>
                <key>maxTextureSize</key>
                <QSize>
                    <key>width</key>
                    <int>-1</int>
                    <key>height</key>
                    <int>-1</int>
                </QSize>
            </struct>
        </array>
        <key>allowRotation</key>
        <true/>
        <key>shapeDebug</key>
        <false/>
        <key>dpi</key>
        <uint>72</uint>
        <key>dataFormat</key>
        <string>json-array</string>
        <key>textureFileName</key>
        <filename></filename>
        <key>flipPVR</key>
        <false/>
        <key>pvrQualityLevel</key>
        <uint>3</uint>
        <key>astcQualityLevel</key>
        <uint>2</uint>
        <key>basisUniversalQualityLevel</key>
        <uint>2</uint>
        <key>etc1QualityLevel</key>
        <uint>70</uint>
        <key>etc2QualityLevel</key>
        <uint>70</uint>
        <key>dxtCompressionMode</key>
        <enum type="SettingsBase::DxtCompressionMode">DXT_PERCEPTUAL</enum>
        <key>ditherType</key>
        <enum type="SettingsBase::DitherType">NearestNeighbour</enum>
        <key>backgroundColor</key>
        <uint>0</uint>
        <key>libGdx</key>
        <struct type="LibGDX">
            <key>filtering</key>
            <struct type="LibGDXFiltering">
                <key>x</key>
                <enum type="LibGDXFiltering::Filtering">Linear</enum>
                <key>y</key>
                <enum type="LibGDXFiltering::Filtering">Linear</enum>
            </struct>
        </struct>
        <key>shapePadding</key>
        <uint>0</uint>
        <key>jpgQuality</key>
        <uint>80</uint>
        <key>pngOptimizationLevel</key>
        <uint>0</uint>
        <key>webpQualityLevel</key>
        <uint>101</uint>
        <key>textureSubPath</key>
        <string></string>
        <key>textureFormat</key>
        <enum type="SettingsBase::TextureFormat">png</enum>
        <key>borderPadding</key>
        <uint>0</uint>
        <key>maxTextureSize</key>
        <QSize>
            <key>width</key>
            <int>2048</int>
            <key>height</key>
            <int>2048</int>
        </QSize>
        <key>fixedTextureSize</key>
        <QSize>
            <key>width</key>
            <int>-1</int>
            <key>height</key>
            <int>-1</int>
        </QSize>
        <key>algorithmSettings</key>
        <struct type="AlgorithmSettings">
            <key>algorithm</key>
            <enum type="AlgorithmSettings::AlgorithmId">Basic</enum>
            <key>freeSizeMode</key>
            <enum type="AlgorithmSettings::AlgorithmFreeSizeMode">Best</enum>
            <key>sizeConstraints</key>
            <enum type="AlgorithmSettings::SizeConstraints">AnySize</enum>
            <key>forceSquared</key>
            <false/>
            <key>maxRects</key>
            <struct type="AlgorithmMaxRectsSettings">
                <key>heuristic</key>
                <enum type="AlgorithmMaxRectsSettings::Heuristic">Best</enum>
            </struct>
            <key>basic</key>
            <struct type="AlgorithmBasicSettings">
                <key>sortBy</key>
                <enum type="AlgorithmBasicSettings::SortBy">Best</enum>
                <key>order</key>
                <enum type="AlgorithmBasicSettings::Order">Ascending</enum>
            </struct>
            <key>polygon</key>
            <struct type="AlgorithmPolygonSettings">
                <key>alignToGrid</key>
                <uint>1</uint>
            </struct>
        </struct>
        <key>dataFileNames</key>
        <map type="GFileNameMap">
            <key>data</key>
            <struct type="DataFile">
                <key>name</key>
                <filename></filename>
            </struct>
        </map>
        <key>multiPackMode</key>
        <enum type="SettingsBase::MultiPackMode">MultiPackOff</enum>
        <key>forceIdenticalLayout</key>
        <false/>
        <key>outputFormat</key>
        <enum type="SettingsBase::OutputFormat">RGBA8888</enum>
        <key>alphaHandling</key>
        <enum type="SettingsBase::AlphaHandling">ClearTransparentPixels</enum>
        <key>contentProtection</key>
        <struct type="ContentProtection">
            <key>key</key>
            <string></string>
        </struct>
        <key>autoAliasEnabled</key>
        <false/>
        <key>trimSpriteNames</key>
        <false/>
        <key>prependSmartFolderName</key>
        <false/>
        <key>autodetectAnimations</key>
        <true/>
        <key>globalSpriteSettings</key>
        <struct type="SpriteSettings">
            <key>scale</key>
            <double>1</double>
            <key>scaleMode</key>
            <enum type="ScaleMode">Smooth</enum>
            <key>extrude</key>
            <uint>0</uint>
            <key>trimThreshold</key>
            <uint>1</uint>
            <key>trimMargin</key>
            <uint>1</uint>
            <key>trimMode</key>
            <enum type="SpriteSettings::TrimMode">None</enum>
            <key>tracerTolerance</key>
            <int>200</int>
            <key>heuristicMask</key>
            <false/>
            <key>defaultPivotPoint</key>
            <point_f>0.5,0.5</point_f>
            <key>writePivotPoints</key>
            <false/>
        </struct>
        <key>individualSpriteSettings</key>
        <map type="IndividualSpriteSettingsMap">
            <key type="filename">Tiles/Tile_01.png</key>
            <key type="filename">Tiles/Tile_02.png</key>
            <key type="filename">Tiles/Tile_03.png</key>
            <key type="filename">Tiles/Tile_04.png</key>
            <key type="filename">Tiles/Tile_05.png</key>
            <key type="filename">Tiles/Tile_06.png</key>
            <key type="filename">Tiles/Tile_07.png</key>
            <key type="filename">Tiles/Tile_08.png</key>
            <key type="filename">Tiles/Tile_09.png</key>
            <key type="filename">Tiles/Tile_10.png</key>
            <key type="filename">Tiles/Tile_11.png</key>
            <key type="filename">Tiles/Tile_12.png</key>
            <key type="filename">Tiles/Tile_13.png</key>
            <key type="filename">Tiles/Tile_14.png</key>
            <key type="filename">Tiles/Tile_15.png</key>
            <key type="filename">Tiles/Tile_16.png</key>
            <key type="filename">Tiles/Tile_17.png</key>
            <key type="filename">Tiles/Tile_18.png</key>
            <key type="filename">Tiles/Tile_19.png</key>
            <key type="filename">Tiles/Tile_20.png</key>
            <key type="filename">Tiles/Tile_21.png</key>
            <key type="filename">Tiles/Tile_22.png</key>
            <key type="filename">Tiles/Tile_23.png</key>
            <key type="filename">Tiles/Tile_24.png</key>
            <key type="filename">Tiles/Tile_25.png</key>
            <key type="filename">Tiles/Tile_26.png</key>
            <key type="filename">Tiles/Tile_27.png</key>
            <key type="filename">Tiles/Tile_28.png</key>
            <key type="filename">Tiles/Tile_29.png</key>
            <key type="filename">Tiles/Tile_30.png</key>
            <key type="filename">Tiles/Tile_31.png</key>
            <key type="filename">Tiles/Tile_32.png</key>
            <key type="filename">Tiles/Tile_33.png</key>
            <key type="filename">Tiles/Tile_34.png</key>
            <key type="filename">Tiles/Tile_35.png</key>
            <key type="filename">Tiles/Tile_36.png</key>
            <key type="filename">Tiles/Tile_37.png</key>
            <key type="filename">Tiles/Tile_38.png</key>
            <key type="filename">Tiles/Tile_39.png</key>
            <key type="filename">Tiles/Tile_40.png</key>
            <key type="filename">Tiles/Tile_41.png</key>
            <key type="filename">Tiles/Tile_42.png</key>
            <key type="filename">Tiles/Tile_43.png</key>
            <key type="filename">Tiles/Tile_44.png</key>
            <key type="filename">Tiles/Tile_45.png</key>
            <key type="filename">Tiles/Tile_46.png</key>
            <key type="filename">Tiles/Tile_47.png</key>
            <key type="filename">Tiles/Tile_48.png</key>
            <key type="filename">Tiles/Tile_49.png</key>
            <key type="filename">Tiles/Tile_50.png</key>
            <key type="filename">Tiles/Tile_51.png</key>
            <key type="filename">Tiles/Tile_52.png</key>
            <key type="filename">Tiles/Tile_53.png</key>
            <key type="filename">Tiles/Tile_54.png</key>
            <key type="filename">Tiles/Tile_55.png</key>
            <key type="filename">Tiles/Tile_56.png</key>
            <key type="filename">Tiles/Tile_57.png</key>
            <key type="filename">Tiles/Tile_58.png</key>
            <key type="filename">Tiles/Tile_59.png</key>
            <key type="filename">Tiles/Tile_60.png</key>
            <key type="filename">Tiles/Tile_61.png</key>
            <key type="filename">Tiles/Tile_62.png</key>
            <key type="filename">Tiles/Tile_63.png</key>
            <key type="filename">Tiles/Tile_64.png</key>
            <struct type="IndividualSpriteSettings">
                <key>pivotPoint</key>
                <point_f>0.5,0.5</point_f>
                <key>spriteScale</key>
                <double>1</double>
                <key>scale9Enabled</key>
                <false/>
                <key>scale9Borders</key>
                <rect>8,8,16,16</rect>
                <key>scale9Paddings</key>
                <rect>8,8,16,16</rect>
                <key>scale9FromFile</key>
                <false/>
            </struct>
        </map>
        <key>fileLists</key>
        <map type="SpriteSheetMap">
            <key>default</key>
            <struct type="SpriteSheet">
                <key>files</key>
                <array>
                    <filename>Tiles/Tile_01.png</filename>
                    <filename>Tiles/Tile_02.png</filename>
                    <filename>Tiles/Tile_03.png</filename>
                    <filename>Tiles/Tile_04.png</filename>
                    <filename>Tiles/Tile_05.png</filename>
                    <filename>Tiles/Tile_06.png</filename>
                    <filename>Tiles/Tile_07.png</filename>
                    <filename>Tiles/Tile_08.png</filename>
                    <filename>Tiles/Tile_09.png</filename>
                    <filename>Tiles/Tile_10.png</filename>
                    <filename>Tiles/Tile_11.png</filename>
                    <filename>Tiles/Tile_12.png</filename>
                    <filename>Tiles/Tile_13.png</filename>
                    <filename>Tiles/Tile_14.png</filename>
                    <filename>Tiles/Tile_15.png</filename>
                    <filename>Tiles/Tile_16.png</filename>
                    <filename>Tiles/Tile_17.png</filename>
                    <filename>Tiles/Tile_18.png</filename>
                    <filename>Tiles/Tile_19.png</filename>
                    <filename>Tiles/Tile_20.png</filename>
                    <filename>Tiles/Tile_21.png</filename>
                    <filename>Tiles/Tile_22.png</filename>
                    <filename>Tiles/Tile_23.png</filename>
                    <filename>Tiles/Tile_24.png</filename>
                    <filename>Tiles/Tile_25.png</filename>
                    <filename>Tiles/Tile_26.png</filename>
                    <filename>Tiles/Tile_27.png</filename>
                    <filename>Tiles/Tile_28.png</filename>
                    <filename>Tiles/Tile_29.png</filename>
                    <filename>Tiles/Tile_30.png</filename>
                    <filename>Tiles/Tile_31.png</filename>
                    <filename>Tiles/Tile_32.png</filename>
                    <filename>Tiles/Tile_33.png</filename>
                    <filename>Tiles/Tile_34.png</filename>
                    <filename>Tiles/Tile_35.png</filename>
                    <filename>Tiles/Tile_36.png</filename>
                    <filename>Tiles/Tile_37.png</filename>
                    <filename>Tiles/Tile_38.png</filename>
                    <filename>Tiles/Tile_39.png</filename>
                    <filename>Tiles/Tile_40.png</filename>
                    <filename>Tiles/Tile_41.png</filename>
                    <filename>Tiles/Tile_42.png</filename>
                    <filename>Tiles/Tile_43.png</filename>
                    <filename>Tiles/Tile_44.png</filename>
                    <filename>Tiles/Tile_45.png</filename>
                    <filename>Tiles/Tile_46.png</filename>
                    <filename>Tiles/Tile_47.png</filename>
                    <filename>Tiles/Tile_48.png</filename>
                    <filename>Tiles/Tile_49.png</filename>
                    <filename>Tiles/Tile_50.png</filename>
                    <filename>Tiles/Tile_51.png</filename>
                    <filename>Tiles/Tile_52.png</filename>
                    <filename>Tiles/Tile_53.png</filename>
                    <filename>Tiles/Tile_54.png</filename>
                    <filename>Tiles/Tile_55.png</filename>
                    <filename>Tiles/Tile_56.png</filename>
                    <filename>Tiles/Tile_57.png</filename>
                    <filename>Tiles/Tile_58.png</filename>
                    <filename>Tiles/Tile_59.png</filename>
                    <filename>Tiles/Tile_60.png</filename>
                    <filename>Tiles/Tile_61.png</filename>
                    <filename>Tiles/Tile_62.png</filename>
                    <filename>Tiles/Tile_63.png</filename>
                    <filename>Tiles/Tile_64.png</filename>
                </array>
            </struct>
        </map>
        <key>ignoreFileList</key>
        <array/>
        <key>replaceList</key>
        <array/>
        <key>ignoredWarnings</key>
        <array/>
        <key>commonDivisorX</key>
        <uint>1</uint>
        <key>commonDivisorY</key>
        <uint>1</uint>
        <key>packNormalMaps</key>
        <false/>
        <key>autodetectNormalMaps</key>
        <true/>
        <key>normalMapFilter</key>
        <string></string>
        <key>normalMapSuffix</key>
        <string></string>
        <key>normalMapSheetFileName</key>
        <filename></filename>
        <key>exporterProperties</key>
        <map type="ExporterProperties"/>
    </struct>
</data>
