import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src')
    }
  },
  server: {
    port: 3002
  },
  test: {
    globals: true,
    environment: 'jsdom', // или 'happy-dom'
    setupFiles: './src/tests/setup.js'
  }
})