export class CreateStockDto {}
