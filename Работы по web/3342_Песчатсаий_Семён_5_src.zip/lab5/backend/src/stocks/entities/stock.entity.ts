export class Stock {}
