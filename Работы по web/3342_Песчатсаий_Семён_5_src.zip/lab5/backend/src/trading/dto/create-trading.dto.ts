export class CreateTradingDto {}
